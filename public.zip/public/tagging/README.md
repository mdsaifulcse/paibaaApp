# jQuery-Tag-It
Just add required CSS & JS files and Script, Thats it! <br/> 

Developed by Alex Ehlke - https://aehlke.github.io/tag-it <br/> 
Customized by Araf Karim - https://github.com/arafkarim ~ https://twitter.com/arafkarim ~ https://fb.com/arafkarim <br/> 
License - https://raw.githubusercontent.com/aehlke/tag-it/master/LICENSE
